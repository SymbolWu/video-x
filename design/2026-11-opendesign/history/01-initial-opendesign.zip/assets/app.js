(() => {
  'use strict';
  const variant = document.body.dataset.variant;
  const data = structuredClone(window.VIDEO_X_DATA.films).map((film, index) => ({ ...film, index }));
  const state = { primary: 'library', section: 'films', category: 'all', search: '', sort: 'added', descending: true, view: 'poster', filters: { watched: 'all', favorite: 'all', rating: 'all' } };
  const paths = {
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
    library: '<rect x="3" y="4" width="5" height="16" rx="1"/><path d="M12 4v16m4-15 5 14"/>',
    discover: '<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5Z"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    landscape: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="m2 15 5-5 5 5 3-3 7 7"/>',
    filter: '<path d="M3 6h18M3 18h18M3 12h18"/><circle cx="8" cy="6" r="2"/><circle cx="16" cy="12" r="2"/><circle cx="9" cy="18" r="2"/>',
    down: '<path d="M12 3v18m-6-6 6 6 6-6"/>',
    up: '<path d="M12 21V3m-6 6 6-6 6 6"/>',
    chevron: '<path d="m7 10 5 5 5-5"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z"/>',
    film: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 3v18m8-18v18M4 8h4m-4 8h4m8-8h4m-4 8h4"/>',
    series: '<rect x="3" y="8" width="18" height="13" rx="2"/><path d="M6 4h12M9 1h6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    play: '<path d="m8 4 13 8-13 8Z"/>',
    settings: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    arrow: '<path d="M19 12H5m6-6-6 6 6 6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>'
  };
  const icon = (name, cls = '') => `<svg class="od-icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.film}</svg>`;
  const escape = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const duration = film => Math.round(film.durationMs / 60000);
  const posterPath = film => film.posterId ? `reference/art/poster-${film.posterId.match(/\d+$/)[0]}.svg` : null;
  const $ = selector => document.querySelector(selector);
  const nav = (cls) => `<nav class="${cls}" aria-label="主要导航">${[['discover','discover','发现'],['library','library','片库'],['favorites','heart','收藏'],['profile','user','我的']].map(([page, glyph, text]) => `<button type="button" data-action="primary" data-page="${page}"${page === 'library' ? ' aria-current="page"' : ''}>${icon(glyph)}<span>${text}</span></button>`).join('')}</nav>`;
  const sections = cls => `<nav class="${cls}" aria-label="片库目录">${[['films','影片',data.length],['actors','演员',0],['series','系列',0]].map(([key,text,count]) => `<button type="button" data-action="section" data-section="${key}" aria-pressed="${key === 'films'}"><span>${text}</span><span class="tab-count">${count}</span></button>`).join('')}</nav>`;
  const brand = `<button type="button" class="brand" data-action="home" aria-label="video-x，返回片库">video<span>—x</span></button>`;
  const management = `<button type="button" class="manage-button" data-action="manage">${icon('settings')}<span>管理端</span></button>`;
  $('#app').innerHTML = `
    <header class="app-top">${brand}${nav('top-nav')}<div class="top-utilities">${management}<button type="button" class="avatar" data-action="primary" data-page="profile" aria-label="我的观影记录">观</button></div></header>
    <aside class="sidebar">${brand}<span class="sidebar-caption">个人影视资料库</span>${nav('side-nav')}<div class="side-catalog"><span class="sidebar-label">目录</span>${sections('side-sections')}</div><div class="sidebar-bottom">${management}<span class="archive-note">好故事，慢慢收藏。</span></div></aside>
    <main id="main" class="library-main"><div class="page-heading"><div><p class="eyebrow">${variant === 'a' ? '个人影视资料库' : '个人影视档案 / 影片'}</p><div class="heading-line"><h1 id="page-title">${variant === 'a' ? '我的片库' : '我的影档'}</h1><span id="collection-count" class="collection-count">12</span></div></div><p class="collection-summary" id="collection-summary"></p></div>
    ${sections('section-tabs')}
    <section id="film-controls" class="film-controls" aria-label="查找影片"><div class="control-bar"><div class="categories" role="group" aria-label="影片分类">${[['all','全部'],['drama','剧情'],['documentary','纪录片']].map(([value,label])=>`<button type="button" data-action="category" data-category="${value}" aria-pressed="${value==='all'}">${label}</button>`).join('')}</div><div class="search-field"><label for="film-search">${icon('search')}<span class="sr-only">搜索影片</span></label><input id="film-search" type="search" placeholder="搜索影片名称" autocomplete="off"><button type="button" id="clear-search" class="icon-button" data-action="clear-search" aria-label="清除搜索" hidden>${icon('close')}</button><span class="search-hint" aria-hidden="true">搜索</span></div><button type="button" id="filter-button" class="filter-button" data-action="filter">${icon('filter')}<span>筛选</span><span id="filter-count" class="filter-count" hidden></span></button></div>
    <div id="active-filters" class="active-filters od-cluster" aria-label="当前条件" hidden></div>
    <div class="result-toolbar"><p id="result-count" class="result-count" role="status" aria-live="polite"></p><div class="view-controls"><div class="sort-control"><label class="sr-only" for="sort-select">排序依据</label><select id="sort-select"><option value="added">最近添加</option><option value="title">名称</option><option value="year">发行年份</option></select>${icon('chevron')}<button type="button" id="sort-direction" class="icon-button" data-action="direction" aria-label="当前降序，切换为升序">${icon('down')}</button></div><span class="toolbar-divider" aria-hidden="true"></span><div class="view-switch" role="group" aria-label="卡片视图"><button type="button" data-action="view" data-view="poster" aria-label="海报视图" aria-pressed="true">${icon('grid')}<span>海报</span></button><button type="button" data-action="view" data-view="landscape" aria-label="横图视图" aria-pressed="false">${icon('landscape')}<span>横图</span></button></div></div></div></section>
    <section id="film-grid" class="film-grid" aria-label="影片列表"></section><section id="empty-state" class="empty-state" hidden></section><footer class="library-footer"><span>每一部，都值得被记住。</span><span id="footer-count"></span></footer></main>
    ${nav('bottom-nav')}
    <dialog id="filter-dialog" class="filter-dialog" aria-labelledby="filter-title"><div class="dialog-heading"><div><p class="eyebrow">缩小查找范围</p><h2 id="filter-title">筛选影片</h2></div><button type="button" class="icon-button" data-close="filter-dialog" aria-label="关闭筛选">${icon('close')}</button></div><div class="filter-body"><fieldset><legend>观看状态</legend><div class="filter-options">${[['all','全部'],['yes','已看'],['no','未看']].map(([value,label])=>`<label><input type="radio" name="watched" value="${value}"><span>${label}</span></label>`).join('')}</div></fieldset><fieldset><legend>喜欢</legend><div class="filter-options">${[['all','全部'],['yes','已喜欢'],['no','未喜欢']].map(([value,label])=>`<label><input type="radio" name="favorite" value="${value}"><span>${label}</span></label>`).join('')}</div></fieldset><label class="rating-filter-label" for="rating-filter">个人评分</label><select id="rating-filter"><option value="all">全部评分</option><option value="unrated">尚未评分</option><option value="5">5 分</option><option value="4">4 分及以上</option><option value="3">3 分及以上</option><option value="2">2 分及以上</option><option value="1">1 分及以上</option></select><p class="filter-help">条件将同时生效，应用后更新片库。</p></div><div class="dialog-actions"><button type="button" class="text-button" data-action="reset-draft">重置</button><div class="od-row"><button type="button" class="secondary-button" data-close="filter-dialog">取消</button><button type="button" class="primary-button" data-action="apply-filters">应用筛选</button></div></div></dialog>
    <dialog id="detail-dialog" class="detail-dialog" aria-labelledby="detail-title"><div class="detail-topbar"><span>影片详情</span><button type="button" class="icon-button" data-close="detail-dialog" aria-label="关闭影片详情">${icon('close')}</button></div><div id="detail-content"></div></dialog>
    <dialog id="utility-dialog" class="utility-dialog" aria-labelledby="utility-title"><div class="dialog-heading"><h2 id="utility-title"></h2><button type="button" class="icon-button" data-close="utility-dialog" aria-label="关闭提示">${icon('close')}</button></div><div id="utility-content" class="utility-content"></div></dialog>
    <div id="toast" class="toast" role="status" aria-live="polite" hidden></div>`;

  function matchingFilms() {
    const query = state.search.trim().toLocaleLowerCase();
    return data.filter(f => (state.primary !== 'favorites' || f.isFavorite)
      && (state.category === 'all' || f.categoryId === state.category)
      && (!query || f.title.toLocaleLowerCase().includes(query))
      && (state.filters.watched === 'all' || Boolean(f.watchedAt) === (state.filters.watched === 'yes'))
      && (state.filters.favorite === 'all' || f.isFavorite === (state.filters.favorite === 'yes'))
      && (state.filters.rating === 'all' || (state.filters.rating === 'unrated' ? f.rating == null : f.rating != null && f.rating >= Number(state.filters.rating))))
      .sort((a,b) => { const result = state.sort === 'added' ? a.index-b.index : state.sort === 'title' ? a.title.localeCompare(b.title,'zh-CN') : a.releaseYear-b.releaseYear; return state.sort === 'added' ? (state.descending ? result : -result) : (state.descending ? -result : result); });
  }
  function cover(film) {
    const path = posterPath(film);
    return path ? `<img class="od-media" src="${path}" width="600" height="900" alt="${escape(film.title)}的抽象海报">` : `<span class="missing-art od-stack">${icon('film')}<span>暂无封面</span><span class="missing-line">VIDEO-X / ${String(film.index+1).padStart(3,'0')}</span></span>`;
  }
  function card(film) {
    return `<article class="film-card od-tile" data-film="${film.id}"><div class="poster-frame"><button type="button" class="poster-open" data-action="open-film" data-film-id="${film.id}" aria-label="查看《${escape(film.title)}》详情"><span class="poster-visual">${cover(film)}</span></button>${film.watchedAt ? `<span class="watched-flag">${icon('check')}<span>已看</span></span>` : ''}<button type="button" class="favorite-button${film.isFavorite?' is-favorite':''}" data-action="favorite" data-film-id="${film.id}" aria-pressed="${film.isFavorite}" aria-label="${film.isFavorite?'取消喜欢':'喜欢'}《${escape(film.title)}》">${icon('heart')}</button></div><div class="card-body"><div class="card-heading"><span class="card-order">${String(film.index+1).padStart(2,'0')}</span><button type="button" class="card-title" data-action="open-film" data-film-id="${film.id}"><span class="od-clamp-2">${escape(film.title)}</span></button></div><div class="card-meta"><span>${film.releaseYear} <span class="meta-dot">·</span> ${escape(film.categoryName)}</span>${film.rating != null ? `<span class="card-rating" aria-label="个人评分 ${film.rating} 分">${icon('star')}<span>${film.rating}</span></span>` : ''}</div><div class="card-bottom"><span class="duration">${duration(film)} 分钟</span><span class="watch-text${film.watchedAt?' is-watched':''}">${film.watchedAt?icon('check'):'<span class="unwatched-dot" aria-hidden="true"></span>'}<span>${film.watchedAt?'已看':'未看'}</span></span></div></div></article>`;
  }
  function chip(label, key) { return `<button type="button" class="filter-chip" data-action="remove-condition" data-condition="${key}" aria-label="清除条件：${escape(label)}"><span class="od-truncate">${escape(label)}</span>${icon('close')}</button>`; }
  function render() {
    const isFilms=state.section==='films';
    $('#film-controls').hidden=!isFilms;
    const films=matchingFilms();
    $('#film-grid').hidden=!isFilms || films.length===0;
    $('#film-grid').className=`film-grid ${state.view==='landscape'?'landscape':''}`;
    $('#film-grid').innerHTML=isFilms?films.map(card).join(''):'';
    const total=state.primary==='favorites'?data.filter(f=>f.isFavorite).length:data.length;
    $('#page-title').textContent=state.primary==='favorites'?'我的收藏':variant==='a'?'我的片库':'我的影档';
    $('#collection-count').textContent=total;
    $('#collection-summary').innerHTML=`<span>${total} 部影片</span><span class="summary-separator">/</span><span>${data.filter(f=>(state.primary!=='favorites'||f.isFavorite)&&f.watchedAt).length} 部已看</span>`;
    $('#result-count').textContent=`${state.category==='all'?'全部影片':state.category==='drama'?'剧情':'纪录片'} · ${films.length} 部`;
    $('#footer-count').textContent=isFilms?`已显示 ${films.length} / ${total} 部影片`:'等待下一次收录';
    $('#clear-search').hidden=!state.search;
    $('.search-hint').hidden=Boolean(state.search);
    const chips=[];
    if(state.search)chips.push(chip(`搜索：${state.search}`,'search'));
    if(state.category!=='all')chips.push(chip(state.category==='drama'?'剧情':'纪录片','category'));
    if(state.filters.watched!=='all')chips.push(chip(state.filters.watched==='yes'?'已看':'未看','watched'));
    if(state.filters.favorite!=='all')chips.push(chip(state.filters.favorite==='yes'?'已喜欢':'未喜欢','favorite'));
    if(state.filters.rating!=='all')chips.push(chip(state.filters.rating==='unrated'?'尚未评分':`${state.filters.rating} 分${state.filters.rating==='5'?'':'及以上'}`,'rating'));
    $('#active-filters').hidden=chips.length===0;
    $('#active-filters').innerHTML=chips.join('')+(chips.length?'<button type="button" class="text-button clear-all" data-action="clear-all">清除全部</button>':'');
    const filterCount=Object.values(state.filters).filter(v=>v!=='all').length;
    $('#filter-count').hidden=filterCount===0;$('#filter-count').textContent=filterCount;
    $('#filter-button').classList.toggle('has-filters',filterCount>0);
    document.querySelectorAll('[data-category]').forEach(el=>el.setAttribute('aria-pressed',el.dataset.category===state.category));
    document.querySelectorAll('[data-section]').forEach(el=>el.setAttribute('aria-pressed',el.dataset.section===state.section));
    document.querySelectorAll('[data-page]').forEach(el=>{if(el.dataset.page===state.primary)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');});
    document.querySelectorAll('[data-view]').forEach(el=>el.setAttribute('aria-pressed',el.dataset.view===state.view));
    const empty=$('#empty-state');empty.hidden=isFilms&&films.length>0;
    if(!isFilms)empty.innerHTML=`<div class="empty-glyph">${icon(state.section==='actors'?'user':'series')}</div><p class="eyebrow">${state.section==='actors'?'演员目录':'系列目录'}</p><h2>还没有${state.section==='actors'?'演员':'系列'}资料</h2><p>当前影片尚未关联${state.section==='actors'?'演员':'系列'}，收录后将在这里整理呈现。</p><button type="button" class="secondary-button" data-action="return-films">返回影片</button>`;
    else if(!films.length) {const hasConditions=state.search||state.category!=='all'||filterCount;empty.innerHTML=`<div class="empty-glyph">${icon(hasConditions?'search':'heart')}</div><p class="eyebrow">${hasConditions?'换个条件，再找找':'留给喜欢的故事'}</p><h2>${hasConditions?'没有找到符合条件的影片':'还没有收藏影片'}</h2><p>${hasConditions?'试试其他片名，或清除搜索与筛选条件。':'点亮海报上的爱心，喜欢的影片就会出现在这里。'}</p><button type="button" class="secondary-button" data-action="${hasConditions?'clear-all':'home'}">${hasConditions?'清除全部条件':'浏览片库'}</button>`;}
  }
  function announce(message) {const el=$('#toast');el.textContent=message;el.hidden=false;clearTimeout(announce.timer);announce.timer=setTimeout(()=>el.hidden=true,2400);}
  function openLayer(dialog, trigger, filmId=null) {
    dialog.returnContext={trigger,filmId,scroll:window.scrollY};
    dialog.showModal();document.body.classList.add('modal-open');
    requestAnimationFrame(()=>dialog.querySelector('[data-close]')?.focus({preventScroll:true}));
  }
  document.querySelectorAll('dialog').forEach(dialog=>{
    dialog.addEventListener('close',()=>{
      const otherOpen=document.querySelector('dialog[open]');
      if(!otherOpen)document.body.classList.remove('modal-open');
      const ctx=dialog.returnContext;
      if(ctx){let trigger=ctx.trigger;if(ctx.filmId){const action=trigger?.dataset.action||'open-film';trigger=document.querySelector(`#film-grid [data-action="${action}"][data-film-id="${ctx.filmId}"]`);}
        if(!trigger?.isConnected)trigger=$('#film-search');
        trigger?.focus({preventScroll:true});if(!otherOpen)window.scrollTo({top:ctx.scroll,behavior:'instant'});
      }
    });
    dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
  });
  let activeFilm=null;
  function renderDetail() {
    const f=data.find(f=>f.id===activeFilm);if(!f)return;
    $('#detail-content').innerHTML=`<div class="detail-hero"><div class="detail-poster">${cover(f)}</div><div class="detail-heading"><p class="eyebrow">${escape(f.categoryName)} / ${f.releaseYear}</p><h2 id="detail-title">${escape(f.title)}</h2><p class="detail-duration">${icon('clock')}<span>${duration(f)} 分钟</span><span>·</span><span>${f.editionCount} 个版本</span></p><div class="detail-play"><button type="button" class="play-button" disabled aria-describedby="play-explanation">${icon('play')}<span>播放影片</span></button><p id="play-explanation">设计样例未绑定媒体文件</p></div></div></div><section class="detail-section"><h3>个人记录</h3><div class="personal-actions"><button type="button" class="secondary-button" data-action="detail-watched" aria-pressed="${Boolean(f.watchedAt)}">${icon('check')}<span>${f.watchedAt?'已看':'标记已看'}</span></button><button type="button" class="secondary-button" data-action="detail-favorite" aria-pressed="${f.isFavorite}">${icon('heart')}<span>${f.isFavorite?'已喜欢':'喜欢'}</span></button></div><div class="personal-rating"><span id="personal-rating-label">个人评分</span><div class="rating-buttons" role="group" aria-labelledby="personal-rating-label">${[1,2,3,4,5].map(n=>`<button type="button" class="rating-star${f.rating>=n?' filled':''}" data-action="rate" data-rating="${n}" aria-pressed="${f.rating===n}" aria-label="评 ${n} 分">${icon('star')}</button>`).join('')}</div><span class="rating-value">${f.rating==null?'未评分':`${f.rating} / 5`}</span><button type="button" class="text-button" data-action="clear-rating"${f.rating==null?' disabled':''}>清除</button></div></section><section class="detail-section"><h3>影片资料</h3><p class="synopsis">${escape(f.summary)}</p><dl class="film-facts"><div><dt>发行日期</dt><dd>${f.releaseDate}</dd></div><div><dt>影片分类</dt><dd>${escape(f.categoryName)}</dd></div><div><dt>演员</dt><dd>${f.actorNames.length?escape(f.actorNames.join('、')):'暂无关联演员'}</dd></div><div><dt>系列</dt><dd>暂无关联系列</dd></div></dl></section><section class="detail-section editions-section"><div class="section-heading"><h3>版本信息</h3><span>${f.editionCount} 个版本</span></div>${f.editions.map(edition=>`<div class="edition-row"><span class="edition-icon">${icon('film')}</span><div class="od-field od-fill"><span class="edition-name">${escape(edition.name)} ${edition.isDefault?'<span class="default-tag">默认</span>':''}</span><span class="edition-meta">${edition.height}p · ${duration(f)} 分钟</span></div><button type="button" class="icon-button" data-action="edition-info" data-edition="${edition.id}" aria-label="查看${escape(edition.name)}版本信息">${icon('info')}</button></div>`).join('')}</section>`;
  }
  function showUtility(title,content,trigger) {$('#utility-title').textContent=title;$('#utility-content').innerHTML=content;openLayer($('#utility-dialog'),trigger);}
  function resetAll() {state.search='';state.category='all';state.filters={watched:'all',favorite:'all',rating:'all'};$('#film-search').value='';render();}
  function syncDraft(filters) {for(const key of ['watched','favorite'])$(`#filter-dialog input[name="${key}"][value="${filters[key]}"]`).checked=true;$('#rating-filter').value=filters.rating;}
  function mutateDetail(action,value) {const film=data.find(f=>f.id===activeFilm);if(!film)return;if(action==='detail-watched')film.watchedAt=film.watchedAt?null:new Date().toISOString();if(action==='detail-favorite')film.isFavorite=!film.isFavorite;if(action==='rate')film.rating=Number(value);if(action==='clear-rating')film.rating=null;render();const scroll=$('#detail-dialog').scrollTop;renderDetail();$('#detail-dialog').scrollTop=scroll;const target=$(`#detail-dialog [data-action="${action}"]${action==='rate'?`[data-rating="${value}"]`:''}`);if(target&&!target.disabled)target.focus({preventScroll:true});else $('#detail-dialog [data-action="rate"]').focus({preventScroll:true});}
  document.addEventListener('click',event=>{
    const button=event.target.closest('button');if(!button||button.disabled)return;
    if(button.dataset.close){$(`#${button.dataset.close}`).close();return;}
    const {action}=button.dataset;if(!action)return;
    if(action==='home'){state.primary='library';state.section='films';resetAll();return;}
    if(action==='primary'){
      const page=button.dataset.page;
      if(page==='discover'){showUtility('发现','<div class="utility-empty">'+icon('discover')+'<h3>新的故事，慢慢发现</h3><p>这里暂时没有新的发现内容。先回到片库，重访已经收录的影片。</p><button type="button" class="primary-button" data-close="utility-dialog">继续浏览片库</button></div>',button);return;}
      if(page==='profile'){showUtility('我的观影',`<p class="utility-lead">记录每一次与好故事的相遇。</p><div class="profile-stats">${[[data.filter(f=>f.watchedAt).length,'部已看'],[data.filter(f=>f.isFavorite).length,'部喜欢'],[data.filter(f=>f.rating!=null).length,'部已评分']].map(([value,label])=>`<div class="od-stat"><strong>${value}</strong><span>${label}</span></div>`).join('')}</div>`,button);return;}
      state.primary=page;state.section='films';render();return;
    }
    if(action==='section'){state.section=button.dataset.section;render();return;}
    if(action==='return-films'){state.section='films';render();[...document.querySelectorAll('[data-section="films"]')].find(el=>el.getClientRects().length)?.focus({preventScroll:true});return;}
    if(action==='category'){state.category=button.dataset.category;render();return;}
    if(action==='clear-search'){state.search='';$('#film-search').value='';render();$('#film-search').focus({preventScroll:true});return;}
    if(action==='clear-all'){resetAll();$('#film-search').focus({preventScroll:true});return;}
    if(action==='remove-condition'){const key=button.dataset.condition;if(key==='search'){state.search='';$('#film-search').value='';}else if(key==='category')state.category='all';else state.filters[key]='all';render();$('#filter-button').focus({preventScroll:true});return;}
    if(action==='direction'){state.descending=!state.descending;$('#sort-direction').innerHTML=icon(state.descending?'down':'up');$('#sort-direction').setAttribute('aria-label',`当前${state.descending?'降序':'升序'}，切换为${state.descending?'升序':'降序'}`);render();return;}
    if(action==='view'){state.view=button.dataset.view;render();return;}
    if(action==='filter'){syncDraft(state.filters);openLayer($('#filter-dialog'),button);return;}
    if(action==='reset-draft'){syncDraft({watched:'all',favorite:'all',rating:'all'});return;}
    if(action==='apply-filters'){state.filters={watched:$('#filter-dialog input[name="watched"]:checked').value,favorite:$('#filter-dialog input[name="favorite"]:checked').value,rating:$('#rating-filter').value};render();$('#filter-dialog').close();return;}
    if(action==='open-film'){activeFilm=button.dataset.filmId;renderDetail();openLayer($('#detail-dialog'),button,activeFilm);return;}
    if(action==='favorite'){const film=data.find(f=>f.id===button.dataset.filmId);film.isFavorite=!film.isFavorite;render();const next=document.querySelector(`#film-grid [data-action="favorite"][data-film-id="${film.id}"]`);(next||$('#film-search')).focus({preventScroll:true});announce(film.isFavorite?'已加入喜欢':'已取消喜欢');return;}
    if(['detail-watched','detail-favorite','rate','clear-rating'].includes(action)){mutateDetail(action,button.dataset.rating);return;}
    if(action==='manage'){showUtility('管理端','<p class="utility-lead">管理端尚未连接</p><p>这里保留管理入口，当前无法添加、修改或移除媒体文件。</p><button type="button" class="secondary-button" data-close="utility-dialog">返回片库</button>',button);return;}
    if(action==='edition-info'){const f=data.find(f=>f.id===activeFilm),edition=f.editions.find(e=>e.id===button.dataset.edition);showUtility('版本信息',`<dl class="utility-facts"><div><dt>版本名称</dt><dd>${escape(edition.name)}</dd></div><div><dt>画面高度</dt><dd>${edition.height}p</dd></div><div><dt>影片时长</dt><dd>${duration(f)} 分钟</dd></div></dl><p class="utility-notice">设计样例未绑定媒体文件</p>`,button);}
  });
  $('#film-search').addEventListener('input',event=>{state.search=event.target.value;render();});
  $('#sort-select').addEventListener('change',event=>{state.sort=event.target.value;render();});
  render();
})();
