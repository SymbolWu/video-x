window.VIDEO_X_DATA = {
  "films": [
    {
      "id": "sample-film-1",
      "title": "最后一班渡轮",
      "kind": "film",
      "categoryId": "documentary",
      "categoryName": "纪录片",
      "releaseYear": 2026,
      "releaseDate": "2026-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 5460000,
      "posterId": "sample-poster-0",
      "backdropId": null,
      "watchedAt": "2026-11-20T12:00:00Z",
      "isFavorite": false,
      "rating": 4,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-0",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-2",
      "title": "山海之间",
      "kind": "film",
      "categoryId": "drama",
      "categoryName": "剧情",
      "releaseYear": 2025,
      "releaseDate": "2025-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 5640000,
      "posterId": "sample-poster-1",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-1",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-3",
      "title": "雨停之前",
      "kind": "film",
      "categoryId": "documentary",
      "categoryName": "纪录片",
      "releaseYear": 2024,
      "releaseDate": "2024-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 5820000,
      "posterId": "sample-poster-2",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": true,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-2",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-4",
      "title": "漫长的夏日：写给那年没有寄出的信",
      "kind": "film",
      "categoryId": "drama",
      "categoryName": "剧情",
      "releaseYear": 2023,
      "releaseDate": "2023-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 6000000,
      "posterId": "sample-poster-3",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": 4,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-3",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-5",
      "title": "午夜放映室",
      "kind": "film",
      "categoryId": "documentary",
      "categoryName": "纪录片",
      "releaseYear": 2022,
      "releaseDate": "2022-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 6180000,
      "posterId": "sample-poster-4",
      "backdropId": null,
      "watchedAt": "2026-11-20T12:00:00Z",
      "isFavorite": false,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-4",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-6",
      "title": "无声的街道",
      "kind": "film",
      "categoryId": "drama",
      "categoryName": "剧情",
      "releaseYear": 2026,
      "releaseDate": "2026-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 6360000,
      "posterId": "sample-poster-5",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-5",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-7",
      "title": "深蓝回声",
      "kind": "film",
      "categoryId": "documentary",
      "categoryName": "纪录片",
      "releaseYear": 2025,
      "releaseDate": "2025-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 6540000,
      "posterId": "sample-poster-6",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": 4,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-6",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-8",
      "title": "穿过旷野",
      "kind": "film",
      "categoryId": "drama",
      "categoryName": "剧情",
      "releaseYear": 2024,
      "releaseDate": "2024-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 6720000,
      "posterId": "sample-poster-7",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-7",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-9",
      "title": "旧时光的来信",
      "kind": "film",
      "categoryId": "documentary",
      "categoryName": "纪录片",
      "releaseYear": 2023,
      "releaseDate": "2023-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 6900000,
      "posterId": null,
      "backdropId": null,
      "watchedAt": "2026-11-20T12:00:00Z",
      "isFavorite": false,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-8",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-10",
      "title": "日落以西",
      "kind": "film",
      "categoryId": "drama",
      "categoryName": "剧情",
      "releaseYear": 2022,
      "releaseDate": "2022-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 7080000,
      "posterId": "sample-poster-9",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": 4,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-9",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-11",
      "title": "归途",
      "kind": "film",
      "categoryId": "documentary",
      "categoryName": "纪录片",
      "releaseYear": 2026,
      "releaseDate": "2026-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 7260000,
      "posterId": "sample-poster-10",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-10",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    },
    {
      "id": "sample-film-12",
      "title": "星河入梦",
      "kind": "film",
      "categoryId": "drama",
      "categoryName": "剧情",
      "releaseYear": 2025,
      "releaseDate": "2025-05-12",
      "actors": [],
      "franchises": [],
      "actorNames": [],
      "fileCount": 1,
      "editionCount": 1,
      "linkedFileCount": 1,
      "durationMs": 7440000,
      "posterId": "sample-poster-11",
      "backdropId": null,
      "watchedAt": null,
      "isFavorite": false,
      "rating": null,
      "stateRevision": 1,
      "summary": "这是一条用于界面设计试验的合成影片资料，不关联任何真实媒体文件。",
      "editions": [
        {
          "id": "sample-edition-11",
          "name": "原版",
          "isDefault": true,
          "height": 1080
        }
      ]
    }
  ]
};
