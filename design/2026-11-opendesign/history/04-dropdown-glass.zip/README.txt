video-x · 版本下拉与毛玻璃原型

本目录运行 python3 -m http.server 8089，然后打开 http://localhost:8089/detail.html?id=dune2 。

版本按钮就地展开下拉菜单，点选即切换。滚动片库可看到导航与控制区的深色玻璃效果。
保留20部影片、6个系列与演员/系列独立作品页，使用会话样本状态，不接真实媒体。
验收记录见 browser-review-glass.json，设计说明见 design-notes-glass.json。
