video-x · Infuse参考两屏原型

在本目录运行 python3 -m http.server 8089，再打开 http://localhost:8089/ 。

片库：index.html
详情：detail.html?id=dune2

这是设计样本，个人状态仅保存在浏览器会话中；未连接真实媒体。
图片来源见 sources.json。正式应用源码未修改。
