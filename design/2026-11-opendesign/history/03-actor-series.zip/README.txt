video-x · OpenDesign 观看端精修原型

在本目录运行 python3 -m http.server 8089，然后打开 http://localhost:8089/ 。

片库 index.html；演员目录 index.html?tab=people；系列目录 index.html?tab=series。
演员和系列卡片分别进入独立作品页，再进入影片详情并逐层返回。
本轮数据：20部影片、6个系列；个人状态为会话样本，未接入真实媒体。
实际界面与交互验收记录见 browser-review.json，素材来源见 references/sources.json。
